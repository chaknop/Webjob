 <div class=" overflownone">
    <div class="col-md-3 information nopaddingleft nopaddingright hidden-sm hidden-xs">
         <h3>Why Us</h3>
         <ul class="information_menu">
            <li class="active" data-id="1"><a href="#"><i class="fa fa-calendar-plus-o"></i> OVERVIEW</a></li>
            <li data-id="2"><a href="#"><i class="fa fa-commenting-o"></i> BENEFITS OF USING JNGTRAVELPRO</a></li>
            <li data-id="3"><a href="#"><i class="fa fa-medkit"></i> Training and Consulting project</a></li>         
         </ul>
       
    </div>
    <div class="col-md-9 nopaddingleft nopaddingright">
       <div class="slideshow">
          <div class="overlay-id1 overlay-item">
             <h3><a href="#">Choose option</a></h3>
                <ul class="quickmenu">
                  <li><a href="#" title="#">Create and enter the tourism products:</a></li>
                  <li><a href="#" title="#">Sell your products to your partners (B2B)</a></li>
                  <li><a href="#" title="#">Monitor the reservation process and prepare all supporting documentation</a></li>
                  <li><a href="#" title="#">Prepare various reports.</a></li>
                  <li><a href="#" title="#">Link multiple offices.</a></li>
                  <li><a href="#" title="#">Edit the content of your web site (Optional)</a></li>
                  <li><a href="#" title="#">Link multiple offices.</a></li> 
                  <li><a href="#" title="#">Edit the content of your web site (Optional).</a></li> 
                  <li><a href="#" title="#">Add special offers and publish them on the Internet (Optional)</a></li>
              </ul>
          </div>
          <div class="overlay-id2 overlay-item">
            <h3><a href="#">Choose option</a></h3>
                <ul class="quickmenu">             
                  <li><a href="#" title="#">Map your actual business processes to the travel software,</a></li>
                  <li><a href="#" title="#">Understand how the SYSTEM is intended to be used,</a></li>
                  <li><a href="#" title="#">Understand how the SYSTEM will work in real life situations,</a></li>
                  <li><a href="#" title="#">Understand how the SYSTEM will provide the benefits you require,</a></li>
              </ul>
          </div>
          <div class="overlay-id3 overlay-item">
             <h3><a href="#">Choose option</a></h3>
                <ul class="quickmenu">
                  <li><a href="#" title="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></li>
                  <li><a href="#" title="#">Praesent posuere tellus a luctus aliquet.</a></li>
                  <li><a href="#" title="#">Phasellus imperdiet mi eget sollicitudin molestie.</a></li>
                  <li><a href="#" title="#">In accumsan tortor eget massa bibendum, ut suscipit elit maximus.</a></li>
                  <li><a href="#" title="#">Nulla sodales turpis vitae dapibus convallis.</a></li>
              </ul>
          </div>          
          <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel">
             <!-- Indicators -->
             <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
             </ol>
             <!-- Wrapper for slides -->
             <div class="carousel-inner" role="listbox">
                <div class="item active">
                   <img src="/photo/slide/img/04.jpg" alt="New York" style="width: 100%;">
                   <div class="carousel-caption">
                      <h3>First slide label</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                   </div>
                </div>
                <div class="item">
                    <img src="/photo/slide/img/02.jpg" alt="New York" style="width: 100%;">
                   <div class="carousel-caption">
                      <h3>First slide label</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                   </div>
                </div>
                <div class="item">
                    <img src="/photo/slide/img/01.jpg" alt="New York" style="width: 100%;">
                   <div class="carousel-caption">
                      <h3>First slide label</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                   </div>
                </div>
             </div>
             <!-- Controls -->
             <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
             <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
             <span class="sr-only">Previous</span>
             </a>
             <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
             <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
             <span class="sr-only">Next</span>
             </a>
          </div>
       </div>
    </div>
 </div>
 <div class="row visible-xs visible-sm ">
    <div class="col-md-12 mobile-menu-bg">
       <ul class="information_menu_mobile">
          <li class="active"><a href="#"><i class="fa fa-calendar-plus-o"></i> <span class="hidden-xs">Lorem ipsum</span></a></li>
          <li><a href="#"><i class="fa fa-commenting-o"></i> <span class="hidden-xs">Praesent posuere</span></a></li>
          <li><a href="#"><i class="fa fa-medkit"></i> <span class="hidden-xs">Phasellus imperdiet</span></a></li>
          <li><a href="#"><i class="fa fa-heartbeat"></i> <span class="hidden-xs">In accumsan</span></a></li>
       </ul>
       <div class="clearfix"></div>
    </div>
 </div>
