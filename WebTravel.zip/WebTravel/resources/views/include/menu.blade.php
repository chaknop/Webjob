<nav class="navbar navbar" id="menu-nav">
	<div class="containe-fluid" id="menu-header">
	    <div class="navbar-header">
	      	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		       <!--  <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>   -->                      
		        <span class="glyphicon glyphicon-menu-hamburger"></span>
	      	</button>
	      <a class="navbar-brand" id="web-logo" href="#">
	      	<img style="width: 309px;" src="/img/demo-logo.png" class="img-responsive" id="img-logo">
	      </a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
		    <ul class="nav navbar-nav" id="nav-ul">
		        <li class="active"><a href="#">About Us</a></li>
		        <li class="active"><a href="#">Our Solutions</a></li>
		        <li class="active"><a href="#">Our Service</a></li>
		       <!--  <li class="dropdown">
		          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
		          <ul class="dropdown-menu">
		            <li><a href="#">Page 1-1</a></li>
		            <li><a href="#">Page 1-2</a></li>
		            <li><a href="#">Page 1-3</a></li>
		          </ul>
		        </li> -->
		        <li><a href="#">Client</a></li>
		        <li><a href="#">Partner</a></li>
		    </ul>
		    <!-- <ul class="nav navbar-nav navbar-right">
		        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
		        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		    </ul> -->
	    </div>
	</div>
</nav>
