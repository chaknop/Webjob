
<footer class="well">
	<div class="container">
		<div class="col-md-3 col-xs-6">
			<ul class="list-unstyled">
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
			</ul>
		</div>
		<div class="col-md-3 col-xs-6">
			<ul class="list-unstyled">
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
			</ul>
		</div>
		<div class="col-md-3 col-xs-6">
			<ul class="list-unstyled">
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
			</ul>
		</div>
		<div class="col-md-3 col-xs-6">
			<ul class="list-unstyled">
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
				<li> welcome</li>
			</ul>
		</div>
		<div class="clear"></div>
	</div>
</footer>