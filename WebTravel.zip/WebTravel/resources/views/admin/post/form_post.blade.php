@extends('layout.backend')

@section('content')
<div class="wrapper">
  @include('admin.include.header')
  <!-- Left side column. contains the logo and sidebar -->
  @include('admin.include.leftMenu')
  <!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
	    <section class="content row">
	    	<form method="POST" action="{{ route('addPost') }}" enctype="multipart/form-data">
	    		{{ csrf_field() }}
				<section class="col-md-8 connectedSortable">
					<div class="panel">
						<div class="box-header">			
					       <h3>Add New Post </h3>			  
					    </div>
						<div class="row">						    
						    <div class="box-body">
						      	<div class="col-md-12 col-md-12">		                   
			                    	<div class="form-group">
			                            <input type="text" id="title" name="title" class="form-control input-md" placeholder="New Title" >
			                        </div>		                            
			                        <div class="row">
			                            <div class="col-xs-12 col-sm-6 col-md-6">
			                            	<div class="form-group">
				                               <select class="form-control" id="category" name="category">
				                               		<option value="">Choose Type</option>
				                               		@foreach(\App\Category::all() as $cat)
				                               		<option value="{{$cat->id}}">{{$cat->title}}</option>
				                               		@endforeach
				                               </select>
				                            </div>
			                            </div>
			                            <div class="col-xs-12 col-sm-6 col-md-6">
			                                <div class="form-group">
				                                <input type="text" id="order" name="order" class="form-control input-md" placeholder="Order title" >
			                                </div>
			                            </div>
			                        </div>	                                
			                      	<div class="form-group">
			                      		<div class="row" style="padding: 4px;">
			                            	<div class="box-body">							            
								                <textarea id="intro" name="intro" class="textarea form-control" placeholder="Place some text here"></textarea>	
								            </div>
							            </div>
			                        </div>
			                        <hr class="colorgraph">
				                </div>        
						  	</div>
					  	</div>				  
				  	</div>
				</section>
				<section class="col-md-4 connectedSortable">
					<div class="box box-solid">
					    <div class="box-header"></div>		     
					    <div class="panel">
				    		<div class="col-md-12">
				    			<label>Feature Image</label>
				    			<hr style="margin-top: 0px; margin-bottom: 4px;">
				    			<a id="choosImg" href="javascript::void(0)">Choose Image</a>
					        	<input name="image" type='file' id="imgInp"/>
					        	<center>
							    	<img class="img-responsive" id="blah" src="#"  style="display: none;"/>
							    </center>
							    <hr class="colorgraph">				           
				                <input onclick="InsertData(event);" type="submit" value="Public" class="btn bg-olive ">
				               	                
				            </div>
			             	<div class="clear"></div>
			             	<br>
						</div>
					</div>			
				</section>   
			<div class="clear"></div>  
			</form>
	    </section>
	    <!-- /.content -->
	</div>
  <!-- /.content-wrapper -->
	<footer class="main-footer">
		<div class="pull-right hidden-xs">
		 
		</div>
		<strong>Copyright &copy; 2016-2017 <a href="#">Almsaeed Studio</a>.</strong> All rights
		reserved.
	</footer>
</div>
@endsection
