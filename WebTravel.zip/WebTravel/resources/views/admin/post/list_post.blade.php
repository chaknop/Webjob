@extends('layout.backend')
@section('title')
	
@endsection
@section('content')
<div class="wrapper">
  	@include('admin.include.header')
  	<!-- Left side column. contains the logo and sidebar -->
  	@include('admin.include.leftMenu')
  	<!-- Content Wrapper. Contains page content -->
  	<div class="content-wrapper">
  		<div class="container">
		    <section class="content-header">
			    <h1>Packages <i class="fa fa-angle-double-right"></i> <a href="{{route('postAddnew')}}">Add New</a></h1>		    
		    </section>
		    <table class="table">
		    	<thead>
		    		<tr>
		    			<td>ID</td>
		    			<td>Title</td>
		    			<td>Date</td>
		    			<td>option</td>
		    		</tr>
		    	</thead>
		    	<tbody>
		    		<tr>
		    			<td></td>
		    			<td></td>
		    			<td></td>
		    			<td></td>
		    		</tr>
		    	</tbody>
		    </table>
	    </div>
   </div>
</div>
@endsection

