<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    //
    public function getList(){
    	return view('admin.post.list_post');
    }

    public function getPost(){
    	return view('admin.post.form_post');
    }

    public function AddPost(Request $req){
    	return $req->file('image');
    }
}
