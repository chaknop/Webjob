

function InsertData(event){

	var title = $("#title").val();
	var category = $("#category").val();
	var order = $("#order").val();
	var intro = $("#intro").val();
	var image = $("#imgInp").file();

	
	alert(image);

	event.preventDefault();
}