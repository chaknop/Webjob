<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', 'HomeController@getHomePage')->name('home');

// Route::get('/monitor', 'HomeController@getMonitor')->name('Monitor');
Route::prefix('admin')->group(function () {

    Route::get('/', 'AdminController@getAdmin');
    Route::get('/post/list', 'PostController@getList')->name('postList');
    Route::get('/post/add-new', 'PostController@getPost')->name('getPost');
    Route::post('/post/add-new', 'PostController@AddPost')->name('addPost');

});




