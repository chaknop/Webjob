<?php $__env->startSection('title'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  	<?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  	<!-- Left side column. contains the logo and sidebar -->
  	<?php echo $__env->make('admin.include.leftMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  	<!-- Content Wrapper. Contains page content -->
  	<div class="content-wrapper">
  		<div class="container">
		    <section class="content-header">
			    <h1>Packages <i class="fa fa-angle-double-right"></i> <a href="<?php echo e(route('postAddnew')); ?>">Add New</a></h1>		    
		    </section>
		    <table class="table">
		    	<thead>
		    		<tr>
		    			<td>ID</td>
		    			<td>Title</td>
		    			<td>Date</td>
		    			<td>option</td>
		    		</tr>
		    	</thead>
		    	<tbody>
		    		<tr>
		    			<td></td>
		    			<td></td>
		    			<td></td>
		    			<td></td>
		    		</tr>
		    	</tbody>
		    </table>
	    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>